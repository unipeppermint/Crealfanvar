# 折叠生物上线与验收清单

版本：1.0 规划基线  
日期：2026年10月15日

本清单以首版正式上架为终点。产品和技术资料已具备进入开发的范围定义；开发、内容制作、真机测试、商店配置和审核仍需逐项完成。所有未勾选条目都是待办，不代表已有验证结果。

## 发布基线

| 维度 | 首版约定 |
| --- | --- |
| 内容 | 36 关，3 章，6 种纸雕生物 |
| 收费 | 免费完整体验，无内购、广告、体力 |
| 系统 | iPhone 竖屏，沿用 iOS 15.0 App Target 最低版本 |
| 语言 | 简体中文、英文 |
| 网络 | 核心功能离线；隐私与支持外链需要网络 |
| 身份 | 无注册和登录 |
| 数据 | 本地进度与设置，首版无分析 SDK |
| 商店名称 | 折叠生物和 Paperkin 均为暂定，发布前查重 |
| 发布地区 | 待开发者确定，并补齐对应地区要求的材料 |
| 审核模式 | 正常用户路径可体验全部核心玩法，无隐藏专用玩法 |

免费方案是当前规划基线。正式设置价格和发布地区前由开发者确认商业决策；不影响开发当前完整离线功能。

## 开发里程碑

| 阶段 | 工作包 | 退出条件 |
| --- | --- | --- |
| M1 规则实现 | 数据结构、交换、四向折叠、可见面、撤销 | 样例和边界单元测试通过 |
| M2 可玩交互 | 棋盘、拖动、点按预览、确认、音效、暂停 | 一个完整关卡可真机连续操作，预览与结果一致 |
| M3 内容验证 | 前 8 关、基础教学、失败与提示 | 首次测试者理解折叠和遮挡，参考解法全部可重放 |
| M4 应用闭环 | 首页、关卡册、通关、图鉴、详情、设置、存档 | 全流程可运行，杀进程后恢复正确 |
| M5 首发内容 | 全部 36 关、6 种生物、24 个阶段素材、中英文 | 内容校验通过，文字和素材齐全 |
| M6 上线质量 | 性能、设备、无障碍、断网、迁移、隐私核验 | 高优先级缺陷清零，验收记录齐全 |
| M7 提审准备 | 图标、实际截图、商店描述、支持、隐私、审核说明 | 上传构建通过验证，商店字段完整 |
| M8 发布 | TestFlight 回归、正式提审、反馈修复、开发者发布 | 审核通过并在选定地区可用 |

M3 是中间检查点，不能以 8 关演示版代替 M5 的首发内容。计划排期应在 M2 后结合折叠动画和美术样件实测工作量确定。

## 功能验收

- [ ] 首次启动和再次启动均有正确入口，关卡没有无效按钮。
- [ ] 普通交换、水平折叠、垂直折叠使用同一套结算规则。
- [ ] 无效交换、预览和取消均不扣步、不改存档。
- [ ] 空白上层纸格遮挡下层，图形显示与逻辑一致。
- [ ] 交叉匹配去重，目标跟随棋子交换。
- [ ] 最后一步完成目标时显示成功。
- [ ] 步数耗尽、无合法动作、提示超时三种状态明确区分。
- [ ] 撤销、重玩和覆盖活动对局不会删除已完成关卡与图鉴。
- [ ] 第 06、12、18、24、30、36 关准确解锁对应生物，重玩不重复奖励。
- [ ] 第 36 关完成后展示完整结束流程，不跳转不存在的下一关。
- [ ] 设置即时生效，帮助离线可读，支持和隐私入口真实有效。
- [ ] 全部中文和英文文案无截断或未替换的本地化键。

## 内容验收

- [ ] 36 关均具备目标、步数、折痕、关卡目的和参考解法。
- [ ] 36 条参考解法均由正式规则引擎重放成功。
- [ ] 初始盘面无自然三连，目标非零，纸面映射合法。
- [ ] 章节内教学与难度逐步推进；同构布局不被当作多份独立内容。
- [ ] 首次折叠在第 02 关出现，遮挡规则有可操作教学。
- [ ] 完成至少两轮前六关用户观察，并修复重复出现的理解问题。
- [ ] 全部插画、音乐、音效、字体及图标来源或授权可追溯。
- [ ] 生物阶段素材完整，不使用占位或与最终样式明显不一致的图片。

## 测试矩阵

| 场景 | 最低验证要求 |
| --- | --- |
| 小屏 iPhone | 棋盘、目标、步数和操作按钮不挤压，触控面积符合规范 |
| 普通与大屏 iPhone | 不拉伸纸纹或图案，弹层安全区正确 |
| 最低支持系统 | 在可用的 iOS 15 真机或环境测试；缺少环境时记录覆盖缺口，不能宣称已验证 |
| 当前系统 | 使用发布前可用的最新正式系统真机回归 |
| VoiceOver | 实际完成第 01、02 关及遮挡教学，不仅验证按钮有标签 |
| 动态字体 | 大字体下关键数字、按钮及帮助内容可见 |
| 减少动态效果 | 不依赖透视动画也能理解和完成关卡 |
| 全程断网 | 首次进入、36 关、图鉴、存档全部可用 |
| 前后台与中断 | 预览、提交、动画、通关四个时间点分别中断恢复 |
| 存档异常 | 当前局损坏、备份恢复、进度损坏、写入失败、旧版本迁移 |
| 长时间使用 | 多关连续游玩、反复进入图鉴、撤销与重玩无明显泄漏 |
| 音频 | 静音、关闭音效、来电或音频中断、恢复、耳机切换 |
| 性能 | 真机测量启动、帧率、卡顿、峰值内存和安装体积 |

初始内部性能目标：普通交互 60 fps、无持续超过 100 ms 的主线程停顿、冷启动目标 2 秒以内、峰值内存预算 150 MB、安装体积预算 100 MB。记录设备和系统版本，未达标先定位原因，不把规划数字写成实际成绩。

## 缺陷优先级

- P0：启动失败、数据被批量清空、隐私行为与申报明显不符。必须修复后再分发。
- P1：必现崩溃、关卡不可解、预览与结果不同、解锁错误、存档无法恢复、核心操作不可达。禁止带入正式提交。
- P2：不阻塞游玩的表现或文案问题。记录影响并在发布前优先修复；影响截图真实性或理解时升级。
- P3：非核心打磨项，记录后续版本计划。

发布门槛为 P0、P1 为零，全部必备功能和内容通过，残留问题有明确影响说明。任何未验证的平台覆盖必须显式记录。

## 商店资料

| 材料 | 要求 | 状态 |
| --- | --- | --- |
| 应用名称与副标题 | 名称查重，文案准确描述实际玩法 | 待制作 |
| 分类与年龄分级 | 根据最终内容填写问卷，建议定位益智游戏 | 待填写 |
| 应用图标 | 独立纸雕主题，符合当期提交规格 | 待制作 |
| 截图 | 用正式构建实际运行画面，覆盖折叠、遮挡、图鉴 | 待实现后采集 |
| 描述与关键词 | 中英文，避免无法证明的唯一性或审核承诺 | 文案草稿见下 |
| 支持地址 | 开发者可维护的有效地址，提供联系方法 | 待提供 |
| 隐私政策 | 与最终数据行为一致，有可访问的有效地址及 App 入口 | 待提供并核验 |
| 隐私标签与清单 | 检查实际数据流、系统 API 和打包资源 | 待核验 |
| 审核备注 | 清楚说明核心路径、离线能力和特殊操作 | 草稿见下 |
| 构建 | 发布前有效的 Xcode、SDK、签名和归档验证 | 待核验 |
| 地区材料 | 按开发者选择的发行地区完成所需核验 | 待确定 |
| 定价 | 当前方案为免费，正式发布配置由开发者确认 | 待设置 |

Apple 要求商店隐私信息反映应用及第三方的实际数据行为，隐私政策应有可访问的地址。首版按无上传设计，但仍需检查最终构建，而不是直接勾选未收集数据。[Apple App Privacy Details](https://developer.apple.com/app-store/app-privacy-details/)

应用信息字段与地区相关材料按实际发行安排填写。[Apple App information](https://developer.apple.com/help/app-store-connect/reference/app-information/app-information/)

截至2026年10月15日，Apple 要求上传构建使用 Xcode 26 或更新版本及 iOS 26 SDK 或相应更新 SDK；最低部署版本与构建 SDK 是两个不同概念，当前 iOS 15.0 部署目标可以保留。打包前仍需复核当时有效的上传要求。[Apple Upcoming Requirements](https://developer.apple.com/news/upcoming-requirements/)

## 商店文案草稿

名称：折叠生物  
英文名：Paperkin  
副标题草稿：折起纸面，解开三消谜题  
英文副标题草稿：Fold paper. Match patterns.

中文描述草稿：

在一张小小纸面上，换一个角度思考三消。

交换相邻图案，也可以沿折痕折起纸张，让远处的图案在表面相遇。观察遮挡、安排顺序，用有限步数完成目标，逐步展开六种纸雕生物。

探索三个章节的 36 个手工关卡。没有倒计时，可以撤销、查看提示，也能随时离开后继续。全部关卡离线可玩，无需注册。

英文描述草稿：

Discover a different way to match on a small sheet of paper.

Swap adjacent patterns, or fold along a crease to bring distant patterns together. Plan around overlapping layers and complete each goal within the move limit.

Explore 36 handcrafted puzzles across three chapters and unfold six paper creatures. Take your time, undo a move, ask for a hint, and continue where you left off. All puzzles work offline, with no account required.

以上文案只在对应功能完成后用于提交。简体中文与英文名称是否可用需要实际检索，不在本次资料中视为已通过。

## 审核备注草稿

The app is an offline, turn-based puzzle game combining adjacent tile swaps with paper folding. No login, purchases, or external hardware are required.

From the home screen, tap Start Folding to begin. Level 1 introduces matching; Level 2 introduces folding. Tap the highlighted crease to preview the folded surface, then tap Confirm Fold to apply the move. Only visible tiles on the top paper layer participate in matches. The sheet unfolds automatically after resolution.

The release includes 36 levels across three chapters and six collectible paper creatures. Undo, hints, local progress saving, and reduced-motion controls are available. Settings can be opened from the home screen.

Please use the normal gameplay flow to experience the folding mechanic. The screenshots show the submitted build.

提交时将按钮名称替换为实际英文界面文案，核对教学路径。最后一句只有正式截图采集完成后保留。

## 发布流程

1. 完成全部功能和内容检查，将真实结果登记到验收记录。
2. 使用 TestFlight 验证首次安装、升级恢复和核心流程，修复高优先级问题。
3. 由开发者确认名称、收费与地区；准备支持、隐私及地区所需材料。
4. 复核隐私清单、商店申报、实际构建、签名和当前 SDK 要求。
5. 从正式构建采集截图，核对描述与功能一致，提交审核。
6. 若收到拒绝，针对具体条款复现并补充真实功能说明或修复，不提交换皮副本。
7. 审核通过后由开发者执行发布，并核对选定地区的商店可见性和安装体验。

Apple 要求审核能够访问应用功能，并建议说明不明显的操作。审核结论由最终应用与材料决定。[Apple 提交前说明](https://developer.apple.com/app-store/review/guidelines/#before-you-submit)

## 发布前外部依赖

开发工作可以按现有方案推进。真正提审前仍需要开发者提供或确认：有效开发者账号及现有签名权限、发布地区、名称使用权、支持联系方式、隐私政策部署地址、所有素材来源和授权，以及适用的地区发行材料。这些是提审条件，不是当前文档整理的阻塞项。
